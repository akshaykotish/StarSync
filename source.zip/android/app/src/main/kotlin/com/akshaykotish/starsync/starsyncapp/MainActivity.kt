package com.akshaykotish.starsync.starsyncapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
